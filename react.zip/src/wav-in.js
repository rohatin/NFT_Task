var WAValidator = require('multicoin-address-validator');
module.exports = WAValidator;

//wav.js is a wallet address validator in order to limit as much as possible bad requests (validation is then proceeded on server side aswell)
//generate wav.js using browserify plugin